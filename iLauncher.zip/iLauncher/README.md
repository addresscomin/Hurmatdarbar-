# iLauncher

iPhone-inspired Android launcher (original design, no Apple assets).

## Phase 1 (this repo)
- Home screen with 4-column app grid, rounded icons
- Dock (Phone, Messages, Browser, Camera)
- Search bar, long-press for App info / Uninstall
- Live refresh when apps are installed/removed
- Shows system wallpaper

## Build
**Option A - GitHub Actions (no PC needed):** push to GitHub, open the *Actions* tab,
run *Build APK*, download the `iLauncher-debug-apk` artifact.

**Option B - Android Studio:** open this folder, press Run.

## Set as default
Settings > Apps > Default apps > Home app > iLauncher.

## Roadmap
Phase 2: Dialer + in-call screen. Phase 3: Messages + Settings. Phase 4: Device-owner lock-down.
