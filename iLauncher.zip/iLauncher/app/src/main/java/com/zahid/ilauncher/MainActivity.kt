package com.zahid.ilauncher

import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Outline
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private lateinit var adapter: AppAdapter
    private lateinit var search: EditText
    private lateinit var grid: RecyclerView
    private lateinit var dock: LinearLayout
    private var allApps: List<AppInfo> = emptyList()

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) = loadApps()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContentView(R.layout.activity_main)

        val root = findViewById<View>(R.id.root)
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(0, bars.top, 0, bars.bottom)
            insets
        }

        search = findViewById(R.id.search)
        grid = findViewById(R.id.grid)
        dock = findViewById(R.id.dock)

        adapter = AppAdapter(
            onClick = { launch(it) },
            onLongClick = { anchor, app -> showMenu(anchor, app) }
        )
        grid.layoutManager = GridLayoutManager(this, 4)
        grid.adapter = adapter

        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) = filter(s?.toString().orEmpty())
        })

        val f = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        registerReceiver(pkgReceiver, f)

        loadApps()
        buildDock()
    }

    override fun onDestroy() {
        unregisterReceiver(pkgReceiver)
        super.onDestroy()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        // Home button pressed: reset to the clean home screen
        if (intent.action == Intent.ACTION_MAIN) resetHome()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        resetHome() // a launcher never closes
    }

    private fun resetHome() {
        search.setText("")
        search.clearFocus()
        grid.scrollToPosition(0)
    }

    private fun loadApps() {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        allApps = pm.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != packageName }
            .map {
                AppInfo(
                    label = it.loadLabel(pm).toString(),
                    packageName = it.activityInfo.packageName,
                    activityName = it.activityInfo.name,
                    icon = it.loadIcon(pm)
                )
            }
            .sortedBy { it.label.lowercase() }
        filter(search.text?.toString().orEmpty())
    }

    private fun filter(q: String) {
        val query = q.trim().lowercase()
        adapter.submit(
            if (query.isEmpty()) allApps
            else allApps.filter { it.label.lowercase().contains(query) }
        )
    }

    private fun launch(app: AppInfo) {
        val i = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
            component = ComponentName(app.packageName, app.activityName)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED
        }
        startActivity(i)
    }

    private fun showMenu(anchor: View, app: AppInfo) {
        val m = PopupMenu(this, anchor)
        m.menu.add(0, 1, 0, "App info")
        m.menu.add(0, 2, 1, "Uninstall")
        m.setOnMenuItemClickListener {
            val uri = Uri.parse("package:${app.packageName}")
            when (it.itemId) {
                1 -> startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, uri))
                2 -> startActivity(Intent(Intent.ACTION_DELETE, uri))
            }
            true
        }
        m.show()
    }

    private fun buildDock() {
        dock.removeAllViews()
        val items = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING),
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_BROWSER),
            Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        )
        val size = (60 * resources.displayMetrics.density).toInt()
        items.forEach { intent ->
            val ri = packageManager.resolveActivity(intent, 0) ?: return@forEach
            val iv = ImageView(this).apply {
                setImageDrawable(ri.loadIcon(packageManager))
                clipToOutline = true
                outlineProvider = object : ViewOutlineProvider() {
                    override fun getOutline(view: View, outline: Outline) {
                        outline.setRoundRect(0, 0, view.width, view.height, view.width * 0.225f)
                    }
                }
                setOnClickListener {
                    startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
            }
            val lp = LinearLayout.LayoutParams(0, size, 1f).apply { setMargins(14, 0, 14, 0) }
            dock.addView(iv, lp)
        }
    }
}
